import { DynamoDBClient, GetItemCommand } from '@aws-sdk/client-dynamodb';

// ✅ Initialize DynamoDB Client
const dynamoClient = new DynamoDBClient({ region: "us-east-1" });

export const handler = async (event) => {
  console.log("Incoming event:", JSON.stringify(event, null, 2));

  let body = event.body ? JSON.parse(event.body) : event;
  console.log("Parsed body:", JSON.stringify(body, null, 2));

  if (!body.subdomain) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing subdomain in request" }),
    };
  }

  const subdomain = body.subdomain;

  // ✅ Correctly define the DynamoDB query
  const params = {
    TableName: "Config",
    Key: {
      subdomain: { S: subdomain }
    }
  };

  try {
    const command = new GetItemCommand(params);
    const data = await dynamoClient.send(command);

    // ✅ Log the full response for debugging
    console.log("DynamoDB response:", JSON.stringify(data, null, 2));

    if (!data.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Configuration not found" }),
      };
    }

    // ✅ Extract the config value correctly
    const configValue = data.Item.config?.M?.value?.N; // Extracting the numeric value

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Configuration retrieved",
        config: configValue
      })
    };
  } catch (error) {
    console.error("Error retrieving configuration:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Could not retrieve configuration" }),
    };
  }
};
