import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

// Make sure to configure the region if needed, e.g., { region: 'us-east-1' }
const dynamo = DynamoDBDocument.from(new DynamoDB({ region: 'us-east-1' }));

export const handler = async (event) => {
  // Parse the incoming event. If the event comes from API Gateway,
  // it might have a stringified JSON in event.body.
  let body;
  try {
    body = event.body ? JSON.parse(event.body) : event;
  } catch (err) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Invalid JSON format' }),
    };
  }

  // Extract the subdomain and config values from the parsed body.
  const { subdomain, config } = body;
  if (!subdomain || !config) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Missing subdomain or config in request body' }),
    };
  }

  // Build the payload for the DynamoDB put (upsert) operation using the correct key names.
  const payload = {
    TableName: 'Config',
    Item: {
      subdomain: subdomain, // Must match the table's partition key (lowercase)
      config: config,
    },
  };

  try {
    // Execute the put operation.
    const result = await dynamo.put(payload);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Configuration updated', result }),
    };
  } catch (error) {
    console.error('Error updating configuration:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Could not update configuration' }),
    };
  }
};
